import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../lib/auth';
import SignOutButton from '../../components/SignOutButton';

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/login');

  return (
    <div className="dash-shell">
      <aside className="dash-nav no-print">
        <div className="dash-nav-company">{session.user.companyName}</div>
        <nav>
          <Link href="/dashboard">Invoices</Link>
          <Link href="/dashboard/invoices/new">+ New invoice</Link>
          <Link href="/dashboard/customers">Customers</Link>
          <Link href="/dashboard/products">Products</Link>
          <Link href="/dashboard/company">Company profile</Link>
        </nav>
        <SignOutButton />
      </aside>
      <main className="dash-main">{children}</main>
    </div>
  );
}
