import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../../lib/auth';
import { prisma } from '../../../../lib/prisma';
import InvoiceForm from '../../../../components/InvoiceForm';

export default async function NewInvoicePage() {
  const session = await getServerSession(authOptions);
  const company = await prisma.company.findUnique({ where: { id: session.user.companyId } });
  const nextNumber = 'INV-' + String(company.invoiceSeq).padStart(4, '0');
  return <InvoiceForm company={company} nextNumber={nextNumber} />;
}
