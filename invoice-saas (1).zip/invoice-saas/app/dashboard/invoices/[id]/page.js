import { notFound } from 'next/navigation';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../../lib/auth';
import { prisma } from '../../../../lib/prisma';
import { computeInvoiceTotals } from '../../../../lib/gst';
import { numberToWordsIndian, CURRENCY_NAMES } from '../../../../lib/numberToWords';
import PrintButton from '../../../../components/PrintButton';

export default async function InvoiceViewPage({ params }) {
  const session = await getServerSession(authOptions);
  const invoice = await prisma.invoice.findUnique({
    where: { id: params.id },
    include: { items: true, company: true }
  });
  if (!invoice || invoice.companyId !== session.user.companyId) notFound();

  const company = invoice.company;
  const totals = computeInvoiceTotals(invoice.items, invoice.taxMode, {
    cgstAmount: invoice.cgstAmount, sgstAmount: invoice.sgstAmount, igstAmount: invoice.igstAmount
  });
  const currName = CURRENCY_NAMES[invoice.currency] || invoice.currency;
  const fmt = (n) => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div>
      <div className="no-print" style={{ marginBottom: 12 }}>
        <PrintButton />
      </div>

      <div className="tax-sheet">
        <div className="title-row">
          <div className="side"></div>
          <div className="center">Tax Invoice</div>
          <div className="side right">{invoice.copyType}</div>
        </div>

        <table className="grid">
          <tbody>
            <tr>
              <td style={{ width: '58%' }}>
                {company.logoDataUrl && <img src={company.logoDataUrl} alt="Logo" style={{ maxWidth: 100, maxHeight: 56, float: 'left', marginRight: 8 }} />}
                <div className="company-name-cell">{company.name}</div>
                <div className="addr-block">{company.address}</div>
                {company.udyam && <div className="kv"><span className="lbl">UDYAM</span><span>{company.udyam}</span></div>}
                {company.gstin && <div className="kv"><span className="lbl">GSTIN/UIN</span><span>{company.gstin}</span></div>}
                {(company.stateName || company.stateCode) && <div className="kv"><span className="lbl">State, Code</span><span>{company.stateName}, {company.stateCode}</span></div>}
                {company.contact && <div className="kv"><span className="lbl">Contact</span><span>{company.contact}</span></div>}
                {company.email && <div className="kv"><span className="lbl">E-Mail</span><span>{company.email}</span></div>}
              </td>
              <td style={{ width: '42%', padding: 0 }}>
                <table className="meta">
                  <tbody>
                    <tr><td><div className="m-lbl">Invoice No.</div>{invoice.invoiceNumber}</td><td><div className="m-lbl">Dated</div>{new Date(invoice.invoiceDate).toLocaleDateString('en-IN')}</td></tr>
                    <tr><td><div className="m-lbl">Delivery Note</div>{invoice.deliveryNote}</td><td><div className="m-lbl">Mode/Terms of Payment</div>{invoice.paymentTerms}</td></tr>
                    <tr><td><div className="m-lbl">Reference No. &amp; Date.</div>{invoice.refNoDate}</td><td><div className="m-lbl">Other References</div>{invoice.otherRef}</td></tr>
                    <tr><td><div className="m-lbl">Buyer's Order No.</div>{invoice.buyersOrderNo}</td><td><div className="m-lbl">Dated</div>{invoice.buyersOrderDate ? new Date(invoice.buyersOrderDate).toLocaleDateString('en-IN') : ''}</td></tr>
                    <tr><td><div className="m-lbl">Dispatch Doc No.</div>{invoice.dispatchDocNo}</td><td><div className="m-lbl">Delivery Note Date</div>{invoice.deliveryNoteDate ? new Date(invoice.deliveryNoteDate).toLocaleDateString('en-IN') : ''}</td></tr>
                    <tr><td><div className="m-lbl">Dispatched through</div>{invoice.dispatchedThrough}</td><td><div className="m-lbl">Destination</div>{invoice.destination}</td></tr>
                    <tr><td colSpan={2}><div className="m-lbl">Terms of Delivery</div>{invoice.termsOfDelivery}</td></tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
              <td style={{ width: '50%' }}>
                <div className="eyebrow">Consignee (Ship to)</div>
                <div className="company-name-cell">{invoice.shipName}</div>
                <div className="addr-block">{invoice.shipAddress}</div>
                {invoice.shipGstin && <div className="kv"><span className="lbl">GSTIN/UIN</span><span>{invoice.shipGstin}</span></div>}
                {invoice.shipPan && <div className="kv"><span className="lbl">PAN/IT No</span><span>{invoice.shipPan}</span></div>}
                {(invoice.shipStateName || invoice.shipStateCode) && <div className="kv"><span className="lbl">State, Code</span><span>{invoice.shipStateName}, {invoice.shipStateCode}</span></div>}
                {invoice.shipContactPerson && <div className="kv"><span className="lbl">Contact person</span><span>{invoice.shipContactPerson}</span></div>}
              </td>
              <td style={{ width: '50%' }}>
                <div className="eyebrow">Buyer (Bill to)</div>
                <div className="company-name-cell">{invoice.billName}</div>
                <div className="addr-block">{invoice.billAddress}</div>
                {invoice.billGstin && <div className="kv"><span className="lbl">GSTIN/UIN</span><span>{invoice.billGstin}</span></div>}
                {invoice.billPan && <div className="kv"><span className="lbl">PAN/IT No</span><span>{invoice.billPan}</span></div>}
                {(invoice.billStateName || invoice.billStateCode) && <div className="kv"><span className="lbl">State, Code</span><span>{invoice.billStateName}, {invoice.billStateCode}</span></div>}
                {invoice.billPlaceOfSupply && <div className="kv"><span className="lbl">Place of Supply</span><span>{invoice.billPlaceOfSupply}</span></div>}
                {invoice.billContactPerson && <div className="kv"><span className="lbl">Contact person</span><span>{invoice.billContactPerson}</span></div>}
              </td>
            </tr>
          </tbody>
        </table>

        <table className="items">
          <thead>
            <tr><th>Sl</th><th>Description of Goods</th><th>HSN/SAC</th><th>GST Rate</th><th>Quantity</th><th>Rate</th><th>per</th><th>Disc. %</th><th>Amount</th></tr>
          </thead>
          <tbody>
            {invoice.items.map((it, i) => (
              <tr key={it.id}>
                <td className="center">{i + 1}</td>
                <td>{it.description}</td>
                <td>{it.hsn}</td>
                <td className="num">{it.gstRate}%</td>
                <td className="num">{it.qty}</td>
                <td className="num">{fmt(it.rate)}</td>
                <td className="center">{it.unit}</td>
                <td className="num">{it.discPct}%</td>
                <td className="num">{fmt(it.amount)}</td>
              </tr>
            ))}
            {invoice.taxMode === 'CGST_SGST' ? (
              <>
                <tr className="foot-row"><td colSpan={7} className="label">CGST Output</td><td></td><td className="num">{fmt(invoice.cgstAmount)}</td></tr>
                <tr className="foot-row"><td colSpan={7} className="label">SGST Output</td><td></td><td className="num">{fmt(invoice.sgstAmount)}</td></tr>
              </>
            ) : (
              <tr className="foot-row"><td colSpan={7} className="label">IGST Output</td><td></td><td className="num">{fmt(invoice.igstAmount)}</td></tr>
            )}
            <tr className="foot-row"><td colSpan={7} className="label">Round Off</td><td></td><td className="num">{fmt(invoice.roundOff)}</td></tr>
            <tr className="foot-row total-row"><td colSpan={4} style={{ textAlign: 'left' }}>Total</td><td className="num">{totals.totalQty}</td><td></td><td></td><td></td><td className="num">{invoice.currency}{fmt(invoice.totalAmount)}</td></tr>
          </tbody>
        </table>

        <div className="words-row">
          <div className="words"><b>Amount Chargeable (in words)</b>{currName} {numberToWordsIndian(invoice.totalAmount)} Only</div>
          <div className="eoe">E. &amp; O.E</div>
        </div>

        <table className="hsn-table">
          <thead>
            {invoice.taxMode === 'CGST_SGST' ? (
              <>
                <tr><th rowSpan={2}>HSN/SAC</th><th rowSpan={2}>Taxable Value</th><th colSpan={2}>CGST</th><th colSpan={2}>SGST/UTGST</th><th rowSpan={2}>Total Tax Amount</th></tr>
                <tr><th>Rate</th><th>Amount</th><th>Rate</th><th>Amount</th></tr>
              </>
            ) : (
              <tr><th>HSN/SAC</th><th>Taxable Value</th><th>IGST Rate</th><th>IGST Amount</th><th>Total Tax Amount</th></tr>
            )}
          </thead>
          <tbody>
            {Object.values(totals.groups).map((g, i) => {
              const half = g.gstRate / 2;
              const cgstAmt = g.taxable * half / 100, sgstAmt = g.taxable * half / 100, igstAmt = g.taxable * g.gstRate / 100;
              const rowTax = invoice.taxMode === 'CGST_SGST' ? cgstAmt + sgstAmt : igstAmt;
              return invoice.taxMode === 'CGST_SGST' ? (
                <tr key={i}><td className="left">{g.hsn}</td><td>{fmt(g.taxable)}</td><td>{half.toFixed(1)}%</td><td>{fmt(cgstAmt)}</td><td>{half.toFixed(1)}%</td><td>{fmt(sgstAmt)}</td><td>{fmt(rowTax)}</td></tr>
              ) : (
                <tr key={i}><td className="left">{g.hsn}</td><td>{fmt(g.taxable)}</td><td>{g.gstRate.toFixed(1)}%</td><td>{fmt(igstAmt)}</td><td>{fmt(rowTax)}</td></tr>
              );
            })}
          </tbody>
        </table>

        <div className="tax-words-row"><b>Tax Amount (in words)</b>{currName} {numberToWordsIndian(Math.round(totals.taxTotal))} Only</div>

        <table className="bottom-grid">
          <tbody>
            <tr>
              <td style={{ width: '55%' }}>
                {company.pan && <div className="kv"><span className="lbl">Company's PAN</span><span>{company.pan}</span></div>}
                <div className="decl-title">Declaration</div>
                <div className="decl-text">{company.declaration}</div>
              </td>
              <td style={{ width: '45%' }}>
                <div className="bank-title">Company's Bank Details</div>
                {company.bankAccName && <div className="kv"><span className="lbl">A/c Holder's Name</span><span>{company.bankAccName}</span></div>}
                {company.bankName && <div className="kv"><span className="lbl">Bank Name</span><span>{company.bankName}</span></div>}
                {company.bankAccNo && <div className="kv"><span className="lbl">A/c No.</span><span>{company.bankAccNo}</span></div>}
                {company.bankIFSC && <div className="kv"><span className="lbl">IFS Code</span><span>{company.bankIFSC}</span></div>}
              </td>
            </tr>
          </tbody>
        </table>

        <table className="sig-grid">
          <tbody>
            <tr>
              <td style={{ width: '50%' }}>Customer's Seal and Signature</td>
              <td style={{ width: '50%' }} className="right">
                <div className="for-company">for {company.name}</div>
                Authorised Signatory
              </td>
            </tr>
          </tbody>
        </table>

        <div className="footer-note">
          {company.jurisdiction && <div>SUBJECT TO {company.jurisdiction} JURISDICTION</div>}
          <div>This is a Computer Generated Invoice</div>
        </div>
      </div>
    </div>
  );
}
