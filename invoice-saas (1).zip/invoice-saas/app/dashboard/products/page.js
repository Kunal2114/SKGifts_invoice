'use client';
import { useEffect, useState } from 'react';

const emptyForm = { id: null, name: '', hsn: '', rate: 0, gstRate: 18, unit: 'Nos' };

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  function load() { fetch('/api/products').then(r => r.json()).then(setProducts); }
  useEffect(load, []);

  function update(field, value) { setForm(f => ({ ...f, [field]: value })); }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const { id, ...data } = form;
    await fetch(id ? `/api/products/${id}` : '/api/products', {
      method: id ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    setSaving(false);
    setForm(emptyForm);
    load();
  }

  async function handleDelete(id) {
    if (!confirm('Delete this product?')) return;
    await fetch(`/api/products/${id}`, { method: 'DELETE' });
    load();
  }

  return (
    <div>
      <h1>Products &amp; services</h1>
      <p className="hint">Save your catalog once here — when creating an invoice, picking a product from the dropdown will auto-fill its description, HSN/SAC, rate, GST rate, and unit.</p>
      <form className="form-grid" onSubmit={handleSubmit}>
        <div className="form-field"><label>Product/service name</label><input value={form.name} onChange={e => update('name', e.target.value)} required /></div>
        <div className="form-field"><label>HSN/SAC</label><input value={form.hsn} onChange={e => update('hsn', e.target.value)} /></div>
        <div className="form-field"><label>Rate</label><input type="number" step="0.01" value={form.rate} onChange={e => update('rate', Number(e.target.value))} /></div>
        <div className="form-field"><label>GST %</label><input type="number" step="0.1" value={form.gstRate} onChange={e => update('gstRate', Number(e.target.value))} /></div>
        <div className="form-field"><label>Unit</label><input value={form.unit} onChange={e => update('unit', e.target.value)} /></div>
        <div className="form-actions">
          <button className="btn primary" type="submit" disabled={saving}>{saving ? 'Saving…' : form.id ? 'Update product' : 'Add product'}</button>
          {form.id && <button type="button" className="btn" onClick={() => setForm(emptyForm)}>Cancel</button>}
        </div>
      </form>

      <table className="data-table">
        <thead><tr><th>Name</th><th>HSN/SAC</th><th>Rate</th><th>GST %</th><th>Unit</th><th></th></tr></thead>
        <tbody>
          {products.map(p => (
            <tr key={p.id}>
              <td>{p.name}</td><td>{p.hsn}</td><td>{p.rate.toFixed(2)}</td><td>{p.gstRate}%</td><td>{p.unit}</td>
              <td>
                <button className="link-btn" onClick={() => { setForm({ ...emptyForm, ...p }); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</button>
                <button className="link-btn danger" onClick={() => handleDelete(p.id)}>Delete</button>
              </td>
            </tr>
          ))}
          {products.length === 0 && <tr><td colSpan={6} className="empty-row">No products yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
