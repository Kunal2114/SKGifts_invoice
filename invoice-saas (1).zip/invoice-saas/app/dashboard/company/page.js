'use client';
import { useEffect, useState } from 'react';

const FIELDS = [
  ['name', 'Company name'],
  ['address', 'Address'],
  ['gstin', 'GSTIN/UIN'],
  ['udyam', 'UDYAM'],
  ['pan', "Company's PAN"],
  ['stateName', 'State name'],
  ['stateCode', 'State code'],
  ['contact', 'Contact'],
  ['email', 'Email'],
  ['bankAccName', "Bank A/c Holder's Name"],
  ['bankName', 'Bank name'],
  ['bankAccNo', 'Bank A/c No.'],
  ['bankIFSC', 'IFS Code'],
  ['jurisdiction', 'Jurisdiction city']
];

export default function CompanyProfilePage() {
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch('/api/company').then(r => r.json()).then(setForm);
  }, []);

  function update(field, value) {
    setForm(f => ({ ...f, [field]: value }));
    setSaved(false);
  }

  function handleLogo(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1.5 * 1024 * 1024) { alert('Please choose a logo image under 1.5MB.'); return; }
    const reader = new FileReader();
    reader.onload = () => update('logoDataUrl', reader.result);
    reader.readAsDataURL(file);
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    await fetch('/api/company', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    setSaving(false);
    setSaved(true);
  }

  if (!form) return <p>Loading…</p>;

  return (
    <div>
      <h1>Company profile</h1>
      <p className="hint">These details automatically populate every invoice you create — including the logo, GSTIN, bank details, and declaration text.</p>
      <form className="form-grid" onSubmit={handleSave}>
        <div className="form-field logo-field">
          <label>Logo</label>
          {form.logoDataUrl && <img src={form.logoDataUrl} alt="Logo" className="logo-preview" />}
          <input type="file" accept="image/*" onChange={handleLogo} />
        </div>
        {FIELDS.map(([key, label]) => (
          <div className="form-field" key={key}>
            <label>{label}</label>
            <input value={form[key] || ''} onChange={e => update(key, e.target.value)} />
          </div>
        ))}
        <div className="form-field full">
          <label>Declaration / terms shown on invoices</label>
          <textarea rows={3} value={form.declaration || ''} onChange={e => update('declaration', e.target.value)} />
        </div>
        <div className="form-actions">
          <button className="btn primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
          {saved && <span className="saved-note">Saved</span>}
        </div>
      </form>
    </div>
  );
}
