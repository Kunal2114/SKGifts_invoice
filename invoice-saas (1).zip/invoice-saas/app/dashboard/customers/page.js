'use client';
import { useEffect, useState } from 'react';

const emptyForm = {
  id: null, name: '', address: '', gstin: '', pan: '', stateName: '', stateCode: '',
  placeOfSupply: '', contactPerson: '', email: '',
  shipName: '', shipAddress: '', shipGstin: '', shipPan: '', shipStateName: '', shipStateCode: '', shipContact: ''
};

export default function CustomersPage() {
  const [customers, setCustomers] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [showShip, setShowShip] = useState(false);
  const [saving, setSaving] = useState(false);

  function load() {
    fetch('/api/customers').then(r => r.json()).then(setCustomers);
  }
  useEffect(load, []);

  function update(field, value) { setForm(f => ({ ...f, [field]: value })); }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    const { id, ...data } = form;
    await fetch(id ? `/api/customers/${id}` : '/api/customers', {
      method: id ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    setSaving(false);
    setForm(emptyForm);
    setShowShip(false);
    load();
  }

  async function handleDelete(id) {
    if (!confirm('Delete this customer?')) return;
    await fetch(`/api/customers/${id}`, { method: 'DELETE' });
    load();
  }

  function editCustomer(c) {
    setForm({ ...emptyForm, ...c });
    setShowShip(!!(c.shipName || c.shipAddress));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div>
      <h1>Customers</h1>
      <form className="form-grid" onSubmit={handleSubmit}>
        <div className="form-field"><label>Name</label><input value={form.name} onChange={e => update('name', e.target.value)} required /></div>
        <div className="form-field full"><label>Address</label><textarea rows={2} value={form.address} onChange={e => update('address', e.target.value)} /></div>
        <div className="form-field"><label>GSTIN/UIN</label><input value={form.gstin} onChange={e => update('gstin', e.target.value)} /></div>
        <div className="form-field"><label>PAN</label><input value={form.pan} onChange={e => update('pan', e.target.value)} /></div>
        <div className="form-field"><label>State name</label><input value={form.stateName} onChange={e => update('stateName', e.target.value)} /></div>
        <div className="form-field"><label>State code</label><input value={form.stateCode} onChange={e => update('stateCode', e.target.value)} /></div>
        <div className="form-field"><label>Place of Supply</label><input value={form.placeOfSupply} onChange={e => update('placeOfSupply', e.target.value)} /></div>
        <div className="form-field"><label>Contact person</label><input value={form.contactPerson} onChange={e => update('contactPerson', e.target.value)} /></div>
        <div className="form-field"><label>Email</label><input value={form.email} onChange={e => update('email', e.target.value)} /></div>

        <button type="button" className="link-btn full" onClick={() => setShowShip(s => !s)}>
          {showShip ? '− Hide' : '+ Add'} a default shipping address for this customer
        </button>
        {showShip && (
          <>
            <div className="form-field"><label>Ship-to name</label><input value={form.shipName} onChange={e => update('shipName', e.target.value)} /></div>
            <div className="form-field full"><label>Ship-to address</label><textarea rows={2} value={form.shipAddress} onChange={e => update('shipAddress', e.target.value)} /></div>
            <div className="form-field"><label>Ship-to GSTIN</label><input value={form.shipGstin} onChange={e => update('shipGstin', e.target.value)} /></div>
            <div className="form-field"><label>Ship-to state</label><input value={form.shipStateName} onChange={e => update('shipStateName', e.target.value)} /></div>
            <div className="form-field"><label>Ship-to state code</label><input value={form.shipStateCode} onChange={e => update('shipStateCode', e.target.value)} /></div>
            <div className="form-field"><label>Ship-to contact</label><input value={form.shipContact} onChange={e => update('shipContact', e.target.value)} /></div>
          </>
        )}

        <div className="form-actions">
          <button className="btn primary" type="submit" disabled={saving}>{saving ? 'Saving…' : form.id ? 'Update customer' : 'Add customer'}</button>
          {form.id && <button type="button" className="btn" onClick={() => { setForm(emptyForm); setShowShip(false); }}>Cancel</button>}
        </div>
      </form>

      <table className="data-table">
        <thead><tr><th>Name</th><th>GSTIN</th><th>State</th><th></th></tr></thead>
        <tbody>
          {customers.map(c => (
            <tr key={c.id}>
              <td>{c.name}</td><td>{c.gstin}</td><td>{c.stateName}</td>
              <td>
                <button className="link-btn" onClick={() => editCustomer(c)}>Edit</button>
                <button className="link-btn danger" onClick={() => handleDelete(c.id)}>Delete</button>
              </td>
            </tr>
          ))}
          {customers.length === 0 && <tr><td colSpan={4} className="empty-row">No customers yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
