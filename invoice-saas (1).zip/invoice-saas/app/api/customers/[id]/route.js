import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { requireSession } from '../../../../lib/requireSession';

// Fetches the record and checks it belongs to the caller's company before
// allowing any mutation — this is what actually enforces multi-tenant
// isolation for update/delete (id alone is globally unique in Postgres,
// so we can't just filter the `where` clause by companyId directly).
async function assertOwnership(id, companyId) {
  const existing = await prisma.customer.findUnique({ where: { id } });
  return existing && existing.companyId === companyId;
}

export async function PUT(req, { params }) {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!(await assertOwnership(params.id, session.user.companyId))) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }
  const body = await req.json();
  const customer = await prisma.customer.update({ where: { id: params.id }, data: body });
  return NextResponse.json(customer);
}

export async function DELETE(req, { params }) {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!(await assertOwnership(params.id, session.user.companyId))) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }
  await prisma.customer.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
