import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { requireSession } from '../../../../lib/requireSession';

async function assertOwnership(id, companyId) {
  const existing = await prisma.product.findUnique({ where: { id } });
  return existing && existing.companyId === companyId;
}

export async function PUT(req, { params }) {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!(await assertOwnership(params.id, session.user.companyId))) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }
  const body = await req.json();
  const product = await prisma.product.update({
    where: { id: params.id },
    data: {
      name: body.name,
      hsn: body.hsn || null,
      rate: Number(body.rate) || 0,
      gstRate: Number(body.gstRate) || 0,
      unit: body.unit || 'Nos'
    }
  });
  return NextResponse.json(product);
}

export async function DELETE(req, { params }) {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!(await assertOwnership(params.id, session.user.companyId))) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }
  await prisma.product.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
