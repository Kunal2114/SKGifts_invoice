import { NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';
import { requireSession } from '../../../lib/requireSession';

const EDITABLE_FIELDS = [
  'name', 'address', 'logoDataUrl', 'gstin', 'udyam', 'pan', 'stateName', 'stateCode',
  'contact', 'email', 'bankAccName', 'bankName', 'bankAccNo', 'bankIFSC', 'declaration', 'jurisdiction'
];

export async function GET() {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const company = await prisma.company.findUnique({ where: { id: session.user.companyId } });
  return NextResponse.json(company);
}

export async function PUT(req) {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const body = await req.json();
  const data = {};
  for (const key of EDITABLE_FIELDS) if (key in body) data[key] = body[key];
  const company = await prisma.company.update({ where: { id: session.user.companyId }, data });
  return NextResponse.json(company);
}
