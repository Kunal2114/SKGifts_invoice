import { NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';
import { requireSession } from '../../../lib/requireSession';
import { computeItemTaxable, determineTaxMode, computeInvoiceTotals } from '../../../lib/gst';

export async function GET() {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const invoices = await prisma.invoice.findMany({
    where: { companyId: session.user.companyId },
    orderBy: { createdAt: 'desc' }
  });
  return NextResponse.json(invoices);
}

export async function POST(req) {
  const session = await requireSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const body = await req.json();
  const companyId = session.user.companyId;

  if (!body.billTo?.name) {
    return NextResponse.json({ error: 'Buyer name is required' }, { status: 400 });
  }
  if (!Array.isArray(body.items) || body.items.length === 0) {
    return NextResponse.json({ error: 'At least one line item is required' }, { status: 400 });
  }

  const company = await prisma.company.findUnique({ where: { id: companyId } });

  // Totals are always recomputed here from the raw item data — the client's
  // numbers are only ever a preview, never trusted for what gets stored.
  const taxMode = determineTaxMode(company.stateCode, body.billTo.stateCode);
  const totals = computeInvoiceTotals(body.items, taxMode, {
    cgstAmount: body.cgstOverride,
    sgstAmount: body.sgstOverride,
    igstAmount: body.igstOverride
  });

  // Sequential invoice numbering: honor a manually typed number if given,
  // otherwise assign the next number from the company's counter. Either way,
  // the counter is advanced so future invoices never collide.
  let invoiceNumber = (body.invoiceNumber || '').trim();
  let nextSeq = company.invoiceSeq;
  const digitsMatch = invoiceNumber.match(/(\d+)\s*$/);
  const usedNumber = digitsMatch ? parseInt(digitsMatch[1], 10) : null;
  if (!invoiceNumber) {
    invoiceNumber = 'INV-' + String(company.invoiceSeq).padStart(4, '0');
    nextSeq = company.invoiceSeq + 1;
  } else if (usedNumber !== null && usedNumber >= company.invoiceSeq) {
    nextSeq = usedNumber + 1;
  }

  const invoice = await prisma.$transaction(async (tx) => {
    await tx.company.update({ where: { id: companyId }, data: { invoiceSeq: nextSeq } });

    let customerId = body.customerId || null;
    if (customerId) {
      const c = await tx.customer.findUnique({ where: { id: customerId } });
      if (!c || c.companyId !== companyId) customerId = null;
    }

    return tx.invoice.create({
      data: {
        companyId,
        customerId,
        invoiceNumber,
        invoiceDate: new Date(body.invoiceDate || Date.now()),
        deliveryNote: body.deliveryNote || null,
        paymentTerms: body.paymentTerms || null,
        refNoDate: body.refNoDate || null,
        otherRef: body.otherRef || null,
        buyersOrderNo: body.buyersOrderNo || null,
        buyersOrderDate: body.buyersOrderDate ? new Date(body.buyersOrderDate) : null,
        dispatchDocNo: body.dispatchDocNo || null,
        deliveryNoteDate: body.deliveryNoteDate ? new Date(body.deliveryNoteDate) : null,
        dispatchedThrough: body.dispatchedThrough || null,
        destination: body.destination || null,
        termsOfDelivery: body.termsOfDelivery || null,
        copyType: body.copyType || 'ORIGINAL FOR RECIPIENT',
        currency: body.currency || '₹',

        billName: body.billTo.name,
        billAddress: body.billTo.address || null,
        billGstin: body.billTo.gstin || null,
        billPan: body.billTo.pan || null,
        billStateName: body.billTo.stateName || null,
        billStateCode: body.billTo.stateCode || null,
        billPlaceOfSupply: body.billTo.placeOfSupply || null,
        billContactPerson: body.billTo.contactPerson || null,

        sameAsBilling: !!body.sameAsBilling,
        shipName: body.shipTo?.name || null,
        shipAddress: body.shipTo?.address || null,
        shipGstin: body.shipTo?.gstin || null,
        shipPan: body.shipTo?.pan || null,
        shipStateName: body.shipTo?.stateName || null,
        shipStateCode: body.shipTo?.stateCode || null,
        shipContactPerson: body.shipTo?.contactPerson || null,

        taxMode,
        cgstAmount: totals.cgstAmount,
        sgstAmount: totals.sgstAmount,
        igstAmount: totals.igstAmount,
        roundOff: totals.roundOff,
        totalAmount: totals.grandTotal,

        items: {
          create: body.items.map((it) => ({
            productId: it.productId || null,
            description: it.description || '',
            hsn: it.hsn || null,
            gstRate: Number(it.gstRate) || 0,
            qty: Number(it.qty) || 0,
            unit: it.unit || 'Nos',
            rate: Number(it.rate) || 0,
            discPct: Number(it.discPct) || 0,
            amount: computeItemTaxable(it.qty, it.rate, it.discPct)
          }))
        }
      }
    });
  });

  return NextResponse.json(invoice);
}
