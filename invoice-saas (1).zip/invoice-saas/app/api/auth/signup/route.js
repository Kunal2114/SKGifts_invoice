import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '../../../../lib/prisma';

// Creates a brand-new Company plus its first admin User in one go.
// This is how a new company signs up to use the tool for the first time.
export async function POST(req) {
  const body = await req.json();
  const { companyName, name, email, password } = body || {};

  if (!companyName || !email || !password) {
    return NextResponse.json({ error: 'Company name, email, and password are required.' }, { status: 400 });
  }
  if (password.length < 8) {
    return NextResponse.json({ error: 'Password must be at least 8 characters.' }, { status: 400 });
  }

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const company = await prisma.company.create({ data: { name: companyName } });
  await prisma.user.create({
    data: {
      email: email.toLowerCase(),
      passwordHash,
      name: name || null,
      companyId: company.id,
      role: 'admin'
    }
  });

  return NextResponse.json({ ok: true });
}
