'use client';
import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({ companyName: '', name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function update(field, value) {
    setForm(f => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data.error || 'Something went wrong.');
      setLoading(false);
      return;
    }
    const signInRes = await signIn('credentials', { redirect: false, email: form.email, password: form.password });
    setLoading(false);
    if (signInRes?.error) {
      router.push('/login');
    } else {
      router.push('/dashboard/company');
      router.refresh();
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1>Create your company account</h1>
        <label>Company name
          <input value={form.companyName} onChange={e => update('companyName', e.target.value)} required />
        </label>
        <label>Your name
          <input value={form.name} onChange={e => update('name', e.target.value)} />
        </label>
        <label>Email
          <input type="email" value={form.email} onChange={e => update('email', e.target.value)} required />
        </label>
        <label>Password
          <input type="password" value={form.password} onChange={e => update('password', e.target.value)} required minLength={8} />
        </label>
        {error && <p className="error-text">{error}</p>}
        <button className="btn primary" type="submit" disabled={loading}>{loading ? 'Creating…' : 'Create account'}</button>
        <p className="auth-switch">Already have an account? <Link href="/login">Sign in</Link></p>
      </form>
    </div>
  );
}
