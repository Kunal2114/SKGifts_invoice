'use client';
import { signOut } from 'next-auth/react';

export default function SignOutButton() {
  return (
    <button className="signout-btn no-print" onClick={() => signOut({ callbackUrl: '/login' })}>
      Sign out
    </button>
  );
}
