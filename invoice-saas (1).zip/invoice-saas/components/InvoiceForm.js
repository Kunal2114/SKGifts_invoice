'use client';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { computeItemTaxable, determineTaxMode, computeInvoiceTotals } from '../lib/gst';
import { numberToWordsIndian, CURRENCY_NAMES } from '../lib/numberToWords';

function emptyItem() {
  return { productId: '', description: '', hsn: '', gstRate: 18, qty: 1, unit: 'Nos', rate: 0, discPct: 0 };
}
const emptyParty = { name: '', address: '', gstin: '', pan: '', stateName: '', stateCode: '', placeOfSupply: '', contactPerson: '' };

export default function InvoiceForm({ company, nextNumber }) {
  const router = useRouter();
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [meta, setMeta] = useState({
    invoiceNumber: nextNumber,
    invoiceDate: new Date().toISOString().slice(0, 10),
    deliveryNote: '', paymentTerms: '', refNoDate: '', otherRef: '',
    buyersOrderNo: '', buyersOrderDate: '', dispatchDocNo: '', deliveryNoteDate: '',
    dispatchedThrough: '', destination: '', termsOfDelivery: '',
    copyType: 'ORIGINAL FOR RECIPIENT', currency: '₹'
  });
  const [customerId, setCustomerId] = useState('');
  const [billTo, setBillTo] = useState(emptyParty);
  const [sameAsBilling, setSameAsBilling] = useState(false);
  const [shipTo, setShipTo] = useState(emptyParty);
  const [items, setItems] = useState([emptyItem()]);
  const [cgstOverride, setCgstOverride] = useState('');
  const [sgstOverride, setSgstOverride] = useState('');
  const [igstOverride, setIgstOverride] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/customers').then(r => r.json()).then(setCustomers);
    fetch('/api/products').then(r => r.json()).then(setProducts);
  }, []);

  function handleCustomerSelect(id) {
    setCustomerId(id);
    const c = customers.find(x => x.id === id);
    if (!c) return;
    setBillTo({
      name: c.name || '', address: c.address || '', gstin: c.gstin || '', pan: c.pan || '',
      stateName: c.stateName || '', stateCode: c.stateCode || '',
      placeOfSupply: c.placeOfSupply || '', contactPerson: c.contactPerson || ''
    });
    if (!sameAsBilling) {
      setShipTo({
        name: c.shipName || c.name || '', address: c.shipAddress || c.address || '',
        gstin: c.shipGstin || '', pan: c.shipPan || '',
        stateName: c.shipStateName || c.stateName || '', stateCode: c.shipStateCode || c.stateCode || '',
        placeOfSupply: '', contactPerson: c.shipContact || c.contactPerson || ''
      });
    }
  }

  useEffect(() => {
    if (sameAsBilling) setShipTo({ ...billTo });
  }, [sameAsBilling, billTo]);

  function updateItem(idx, field, value) {
    setItems(list => list.map((it, i) => i === idx ? { ...it, [field]: value } : it));
  }

  function handleProductSelect(idx, productId) {
    const p = products.find(x => x.id === productId);
    setItems(list => list.map((it, i) => {
      if (i !== idx) return it;
      if (!p) return { ...it, productId: '' };
      return { ...it, productId, description: p.name, hsn: p.hsn || '', gstRate: p.gstRate, rate: p.rate, unit: p.unit };
    }));
  }

  function addItem() { setItems(list => [...list, emptyItem()]); }
  function removeItem(idx) { setItems(list => list.length > 1 ? list.filter((_, i) => i !== idx) : list); }

  const taxMode = useMemo(() => determineTaxMode(company.stateCode, billTo.stateCode), [company.stateCode, billTo.stateCode]);
  const totals = useMemo(() => computeInvoiceTotals(items, taxMode, {
    cgstAmount: cgstOverride, sgstAmount: sgstOverride, igstAmount: igstOverride
  }), [items, taxMode, cgstOverride, sgstOverride, igstOverride]);
  const currName = CURRENCY_NAMES[meta.currency] || meta.currency;

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (!billTo.name) { setError('Please add the buyer name.'); return; }
    setSaving(true);
    const payload = {
      ...meta,
      customerId: customerId || null,
      billTo, shipTo, sameAsBilling,
      items,
      cgstOverride: cgstOverride === '' ? null : Number(cgstOverride),
      sgstOverride: sgstOverride === '' ? null : Number(sgstOverride),
      igstOverride: igstOverride === '' ? null : Number(igstOverride)
    };
    const res = await fetch('/api/invoices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || 'Could not save the invoice.');
      return;
    }
    const invoice = await res.json();
    router.push(`/dashboard/invoices/${invoice.id}`);
  }

  return (
    <form className="invoice-form" onSubmit={handleSubmit}>
      <h1>New invoice</h1>

      <div className="form-row">
        <div className="form-field"><label>Invoice No.</label><input value={meta.invoiceNumber} onChange={e => setMeta(m => ({ ...m, invoiceNumber: e.target.value }))} /></div>
        <div className="form-field"><label>Date</label><input type="date" value={meta.invoiceDate} onChange={e => setMeta(m => ({ ...m, invoiceDate: e.target.value }))} /></div>
        <div className="form-field">
          <label>Currency</label>
          <select value={meta.currency} onChange={e => setMeta(m => ({ ...m, currency: e.target.value }))}>
            <option value="₹">₹ INR</option><option value="$">$ USD</option><option value="€">€ EUR</option><option value="£">£ GBP</option>
          </select>
        </div>
        <div className="form-field">
          <label>Copy type</label>
          <select value={meta.copyType} onChange={e => setMeta(m => ({ ...m, copyType: e.target.value }))}>
            <option>ORIGINAL FOR RECIPIENT</option><option>DUPLICATE FOR TRANSPORTER</option><option>TRIPLICATE FOR SUPPLIER</option>
          </select>
        </div>
      </div>

      <details className="more-meta">
        <summary>More invoice details (delivery note, references, dispatch…)</summary>
        <div className="form-row wrap">
          <div className="form-field"><label>Delivery Note</label><input value={meta.deliveryNote} onChange={e => setMeta(m => ({ ...m, deliveryNote: e.target.value }))} /></div>
          <div className="form-field"><label>Mode/Terms of Payment</label><input value={meta.paymentTerms} onChange={e => setMeta(m => ({ ...m, paymentTerms: e.target.value }))} /></div>
          <div className="form-field"><label>Reference No. &amp; Date</label><input value={meta.refNoDate} onChange={e => setMeta(m => ({ ...m, refNoDate: e.target.value }))} /></div>
          <div className="form-field"><label>Other References</label><input value={meta.otherRef} onChange={e => setMeta(m => ({ ...m, otherRef: e.target.value }))} /></div>
          <div className="form-field"><label>Buyer's Order No.</label><input value={meta.buyersOrderNo} onChange={e => setMeta(m => ({ ...m, buyersOrderNo: e.target.value }))} /></div>
          <div className="form-field"><label>Buyer's Order Date</label><input type="date" value={meta.buyersOrderDate} onChange={e => setMeta(m => ({ ...m, buyersOrderDate: e.target.value }))} /></div>
          <div className="form-field"><label>Dispatch Doc No.</label><input value={meta.dispatchDocNo} onChange={e => setMeta(m => ({ ...m, dispatchDocNo: e.target.value }))} /></div>
          <div className="form-field"><label>Delivery Note Date</label><input type="date" value={meta.deliveryNoteDate} onChange={e => setMeta(m => ({ ...m, deliveryNoteDate: e.target.value }))} /></div>
          <div className="form-field"><label>Dispatched through</label><input value={meta.dispatchedThrough} onChange={e => setMeta(m => ({ ...m, dispatchedThrough: e.target.value }))} /></div>
          <div className="form-field"><label>Destination</label><input value={meta.destination} onChange={e => setMeta(m => ({ ...m, destination: e.target.value }))} /></div>
          <div className="form-field full"><label>Terms of Delivery</label><input value={meta.termsOfDelivery} onChange={e => setMeta(m => ({ ...m, termsOfDelivery: e.target.value }))} /></div>
        </div>
      </details>

      <div className="two-col">
        <div className="party-box">
          <h3>Buyer (Bill to)</h3>
          <select value={customerId} onChange={e => handleCustomerSelect(e.target.value)}>
            <option value="">— Select saved customer or type new below —</option>
            {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input placeholder="Name" value={billTo.name} onChange={e => setBillTo(b => ({ ...b, name: e.target.value }))} />
          <textarea placeholder="Address" rows={2} value={billTo.address} onChange={e => setBillTo(b => ({ ...b, address: e.target.value }))} />
          <input placeholder="GSTIN/UIN" value={billTo.gstin} onChange={e => setBillTo(b => ({ ...b, gstin: e.target.value }))} />
          <input placeholder="PAN/IT No" value={billTo.pan} onChange={e => setBillTo(b => ({ ...b, pan: e.target.value }))} />
          <div className="inline-pair">
            <input placeholder="State" value={billTo.stateName} onChange={e => setBillTo(b => ({ ...b, stateName: e.target.value }))} />
            <input placeholder="Code" value={billTo.stateCode} onChange={e => setBillTo(b => ({ ...b, stateCode: e.target.value }))} />
          </div>
          <input placeholder="Place of Supply" value={billTo.placeOfSupply} onChange={e => setBillTo(b => ({ ...b, placeOfSupply: e.target.value }))} />
          <input placeholder="Contact person" value={billTo.contactPerson} onChange={e => setBillTo(b => ({ ...b, contactPerson: e.target.value }))} />
        </div>
        <div className="party-box">
          <h3>Consignee (Ship to)
            <label className="same-as"><input type="checkbox" checked={sameAsBilling} onChange={e => setSameAsBilling(e.target.checked)} /> Same as buyer</label>
          </h3>
          <input disabled={sameAsBilling} placeholder="Name" value={shipTo.name} onChange={e => setShipTo(s => ({ ...s, name: e.target.value }))} />
          <textarea disabled={sameAsBilling} placeholder="Address" rows={2} value={shipTo.address} onChange={e => setShipTo(s => ({ ...s, address: e.target.value }))} />
          <input disabled={sameAsBilling} placeholder="GSTIN/UIN" value={shipTo.gstin} onChange={e => setShipTo(s => ({ ...s, gstin: e.target.value }))} />
          <input disabled={sameAsBilling} placeholder="PAN/IT No" value={shipTo.pan} onChange={e => setShipTo(s => ({ ...s, pan: e.target.value }))} />
          <div className="inline-pair">
            <input disabled={sameAsBilling} placeholder="State" value={shipTo.stateName} onChange={e => setShipTo(s => ({ ...s, stateName: e.target.value }))} />
            <input disabled={sameAsBilling} placeholder="Code" value={shipTo.stateCode} onChange={e => setShipTo(s => ({ ...s, stateCode: e.target.value }))} />
          </div>
          <input disabled={sameAsBilling} placeholder="Contact person" value={shipTo.contactPerson} onChange={e => setShipTo(s => ({ ...s, contactPerson: e.target.value }))} />
        </div>
      </div>

      <h3>Items</h3>
      <table className="item-table">
        <thead>
          <tr><th>Product</th><th>Description</th><th>HSN/SAC</th><th>GST %</th><th>Qty</th><th>Unit</th><th>Rate</th><th>Disc %</th><th>Amount</th><th></th></tr>
        </thead>
        <tbody>
          {items.map((it, idx) => {
            const amount = computeItemTaxable(it.qty, it.rate, it.discPct);
            return (
              <tr key={idx}>
                <td>
                  <select value={it.productId} onChange={e => handleProductSelect(idx, e.target.value)}>
                    <option value="">— custom —</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </td>
                <td><input value={it.description} onChange={e => updateItem(idx, 'description', e.target.value)} /></td>
                <td><input value={it.hsn} onChange={e => updateItem(idx, 'hsn', e.target.value)} /></td>
                <td><input type="number" step="0.1" value={it.gstRate} onChange={e => updateItem(idx, 'gstRate', Number(e.target.value))} /></td>
                <td><input type="number" step="1" value={it.qty} onChange={e => updateItem(idx, 'qty', Number(e.target.value))} /></td>
                <td><input value={it.unit} onChange={e => updateItem(idx, 'unit', e.target.value)} /></td>
                <td><input type="number" step="0.01" value={it.rate} onChange={e => updateItem(idx, 'rate', Number(e.target.value))} /></td>
                <td><input type="number" step="0.1" value={it.discPct} onChange={e => updateItem(idx, 'discPct', Number(e.target.value))} /></td>
                <td className="amount-cell">{amount.toFixed(2)}</td>
                <td><button type="button" className="remove-btn" onClick={() => removeItem(idx)}>×</button></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button type="button" className="add-row-btn" onClick={addItem}>+ Add line item</button>

      <div className="totals-panel">
        <div className="totals-row"><span>Subtotal</span><span>{totals.totalTaxable.toFixed(2)}</span></div>
        {taxMode === 'CGST_SGST' ? (
          <>
            <div className="totals-row"><span>CGST</span><input type="number" step="0.01" value={cgstOverride} placeholder={(totals.totalTax / 2).toFixed(2)} onChange={e => setCgstOverride(e.target.value)} /></div>
            <div className="totals-row"><span>SGST</span><input type="number" step="0.01" value={sgstOverride} placeholder={(totals.totalTax / 2).toFixed(2)} onChange={e => setSgstOverride(e.target.value)} /></div>
          </>
        ) : (
          <div className="totals-row"><span>IGST</span><input type="number" step="0.01" value={igstOverride} placeholder={totals.totalTax.toFixed(2)} onChange={e => setIgstOverride(e.target.value)} /></div>
        )}
        <div className="totals-row"><span>Round Off</span><span>{totals.roundOff.toFixed(2)}</span></div>
        <div className="totals-row grand"><span>Total</span><span>{meta.currency}{totals.grandTotal.toFixed(2)}</span></div>
        <p className="words-preview">{currName} {numberToWordsIndian(totals.grandTotal)} Only</p>
      </div>

      {error && <p className="error-text">{error}</p>}
      <button className="btn primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save invoice'}</button>
    </form>
  );
}
